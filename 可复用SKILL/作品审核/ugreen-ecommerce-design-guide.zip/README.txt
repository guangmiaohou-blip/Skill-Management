本目录是由 Design Guide.md 重写生成的 UGREEN 绿联电商视觉设计 Skill。
SKILL.md 是可执行入口；references/绿联电商视觉设计规范.md 是规范化文档；references/原始文档-Design Guide.md 只作为来源留档。
当前状态为 candidate，审核通过后才能并入正式品牌规则或自动路由。
