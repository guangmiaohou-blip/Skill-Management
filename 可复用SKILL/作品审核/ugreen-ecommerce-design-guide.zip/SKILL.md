---
name: ugreen-ecommerce-design-guide
description: 执行 UGREEN 绿联电商视觉设计规范，用于电商主图、详情页、官网 Banner、数码产品精修、AI 产品出图和设计审查。控制品牌色、Logo、字体、信息层级、产品占比、构图、光影、材质还原、尺寸和交付检查。该 Skill 默认作为 candidate 使用，审核通过后才能作为正式品牌规则自动调用。
---

# UGREEN 电商视觉设计规范 Skill

本 Skill 将 UGREEN 绿联 Design Guide 转换为可执行的设计与 AI 出图规则。它负责品牌视觉一致性和质量检查，不替代产品专属提示词，也不自动保留参考图中的品牌文字、Logo 或产品；是否保留品牌资产必须由用户确认并遵守授权。

## 执行顺序

1. 识别任务：电商主图、详情页、官网 Banner、产品精修、生活方式图或设计审查。
2. 读取 `references/绿联电商视觉设计规范.md`。
3. 确认产品、平台尺寸、是否保留品牌 Logo/文字、主卖点和交付格式。
4. 先锁定产品结构、比例和材质，再安排版式、颜色、字体和光影。
5. 生成或审查画面后执行质量检查，输出不合格项和修正建议。

## 强制规则

- 品牌主色：`#007934`；活力绿：`#009632`；辅助绿：`#00CE7C`。
- 白底标准为 RGB 255/255/255；浅灰背景不得低于 RGB 240/240/240。
- 绿联 Logo 默认左上角，距离边缘 16px；不得拉伸、旋转、改色或替换字体。
- 信息层级不超过 3 级；主图不堆叠超过 3 条卖点文字。
- 产品主体通常占画面 60%-70%，优先展示核心功能面。
- 产品角度优先使用斜俯视 3/4 角；标准正侧视默认禁用。
- 产品必须保持真实结构、比例、接口布局、丝印位置和材质特征，不得变形。
- 色温以 5500K 中性日光为基准，产品底部只允许极淡接触阴影，不使用硬投影。
- 单张图字体不超过 3 种，最小文字不低于 12px，文字对比度符合 WCAG AA。
- AI 生成时，参考图文字、Logo、图形和品牌元素默认去除；只有用户明确要求保留并确认授权时才可保留。

## 任务分流

### 电商主图

默认使用 800x800px 白底 JPG/PNG。优先采用左文右图：文字区约 40%，产品区约 60%；产品名和型号为低权重标签，核心卖点为最大字号，信任信号为最小字号。

### 官网 Banner

默认参考 1920x600px，保持清晰的产品主体和足够文案留白；背景、产品和文字不得争夺同一视觉焦点。

### AI 产品出图

使用 `exact product proportions, no distortion, accurate logo placement, surface texture visible, material details accurate, commercial catalog quality` 等结构化模块。品牌文字和 Logo 是否出现必须单独确认。

### 设计审查

按品牌符号、色彩、字体、信息层级、产品占比、角度、光影、材质、尺寸、文件格式和文件大小逐项检查，并输出 `pass`、`needs_revision` 或 `blocked`。

## 质量检查输出

```yaml
review_result: pass | needs_revision | blocked
brand_color: pass | needs_revision | not_applicable
logo: pass | needs_revision | user_confirmation_required
typography: pass | needs_revision
information_hierarchy: pass | needs_revision
product_ratio: pass | needs_revision
product_geometry: pass | needs_revision
camera_angle: pass | needs_revision
lighting: pass | needs_revision
material_fidelity: pass | needs_revision
dimensions_and_format: pass | needs_revision
issues: []
recommendations: []
```

## 相关文件

- `references/绿联电商视觉设计规范.md`：统一重写后的详细品牌规范。
- `references/原始文档-Design Guide.md`：原始来源，仅用于追溯，不直接作为执行规则。
- `README.txt`：目录说明。
