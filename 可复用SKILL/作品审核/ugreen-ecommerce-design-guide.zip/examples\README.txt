本目录用于存放通过审核的 UGREEN 电商视觉案例。
当前没有已审核的成功案例，规范化 Design Guide 仍处于 candidate 状态。
